package project;
import java.util.Scanner;
public class ReportCardMain {

	public static void main(String[] args) {
	
		FirstStandard[] first=new FirstStandard[5];
	
		Tenth t=new Tenth();
		Student s=new Student();
		Ninth nth[]=new Ninth[4];
		int n;
		Scanner sc=new Scanner(System.in);
		String c;
		do {
			System.out.println("ENTER CHOICE \n1)Report Card Genrate \n2) Access Student");
		n=sc.nextInt();
		
		switch(n)
		{
		case 1:
			do {
				System.out.println("ENTER CHOICE ADMIN \n1)Primary \n2) Secondary \n3) 10 th");
			n=sc.nextInt();
			
			switch(n)
			{
			case 1:
				
				do {
					System.out.println("ENTER CHOICE ADMIN \n1)1st Standard \n2)2nd Standard"
							+ " \n3) 3rd Standard\n4) 4th Standard\n5) 5th Standard");
				n=sc.nextInt();
				switch(n)
				{
				case 1:
					n--;
				first[n]=new FirstStandard();
				first[n].setData();
				first[n].display();
				first[n].sort();
					break;
				case 2:
					n--;
					first[n]=new FirstStandard();
					first[n].setData();
					first[n].display();
					first[n].sort();
					
					break;
				case 3:
					n--;
					first[n]=new FirstStandard();
					first[n].setData();
					first[n].display();
					first[n].sort();
						break;
					case 4:
						n--;
						first[n]=new FirstStandard();
						first[n].setData();
						first[n].display();
						first[n].sort();
						
						break;
					case 5:
						n--;
						first[n]=new FirstStandard();
						first[n].setData();
						first[n].display();
						first[n].sort();
						
						break;
						default:
							System.out.println("Enter proper choice");
				
				}
					
				
				//sc.nextLine();
				System.out.println("\n you want to continue then Enter yes");
				 c=sc.nextLine();
				}while(c.equals("yes")||c.equals("YES"));
				
				
				
				
				
				break;
			case 2:
			

				do {
					System.out.println("ENTER CHOICE ADMIN \n1)6 th Standard \n2)7th Standard"
							+ " \n3) 8th Standard\n4) 9th Standard");
				n=sc.nextInt();
				switch(n)
				{
				case 1:
					n--;
					nth[n]=new Ninth();
					nth[n].setData1();
					nth[n].display();
					nth[n].sort();
					nth[n].pushstatus();
					nth[n].popstatus();
					break;
				case 2:
					n--;
					nth[n]=new Ninth();
					nth[n].setData1();
					nth[n].display();
					nth[n].sort();
					nth[n].pushstatus();
					nth[n].popstatus();
					
					break;
				case 3:
					n--;
					nth[n]=new Ninth();
					nth[n].setData1();
					nth[n].display();
					nth[n].sort();
					nth[n].pushstatus();
					nth[n].popstatus();
						break;
					case 4:
						n--;
						nth[n]=new Ninth();
						nth[n].setData1();
						nth[n].display();
						nth[n].sort();
						nth[n].pushstatus();
						nth[n].popstatus();
						
						break;
	
						default:
							System.out.println("Enter proper choice");
				
				}
					
				
				//sc.nextLine();
				System.out.println("\n you want to continue then Enter yes");
				 c=sc.nextLine();
				}while(c.equals("yes")||c.equals("YES"));
				
				
				
				
				
				
				break;
             case 3:
            	 t.setData1();
     			t.display();
     			t.sort();
     			t.pushstatus();
     			t.popstatus();
     			
				break;
             default:
					System.out.println("Enter proper choice");
					break;
			}
				////************///
		sc.nextLine();
			System.out.println("ENTER  ADMIN Primary Secondary 10 th data then Enter yes");
		
			 c=sc.nextLine();
			}while(c.equals("yes")||c.equals("YES"));
		
			break;
		case 2:
			do {
				System.out.println("ENTER CHOICE STUDENTS \n1)Primary \n2) Secondary \n3) 10 th");
			n=sc.nextInt();
			
			switch(n)
			{
			case 1:
					
				do {
					System.out.println("ENTER CHOICE STUDENTS \n1)1st Standard \n2)2nd Standard"
							+ " \n3) 3rd Standard\n4) 4th Standard\n5) 5th Standard");
				n=sc.nextInt();
				switch(n)
				{
				case 1:
					n--;
					s.setData();
					System.out.println("****************************************");
					System.out.println("             1 St STANDARD              ");
					first[n].check();
					break;
				case 2:
					n--;
					s.setData();
					System.out.println("****************************************");
					System.out.println("             2 nd STANDARD              ");
					first[n].check();
					
					
					break;
				case 3:
					n--;
					s.setData();
					System.out.println("****************************************");
					System.out.println("              3rd STANDARD              ");
					first[n].check();
				
						break;
					case 4:
						n--;
						s.setData();
						System.out.println("****************************************");
						System.out.println("             4 th STANDARD              ");
			
						first[n].check();
						
						break;
					case 5:
						n--;
						s.setData();
						System.out.println("****************************************");
						System.out.println("             5 th STANDARD              ");
						first[n].check();
						
						break;
						default:
							System.out.println("Enter proper choice");
				
				}
					
				
				sc.nextLine();
				System.out.println("\n you want to continue then Enter yes");
				 c=sc.nextLine();
				}while(c.equals("yes")||c.equals("YES"));
				
				
				
				
				
				
	
				break;
			case 2:
		
				do {
					System.out.println("ENTER CHOICE STUDENT \n1)6 th Standard \n2)7th Standard"
							+ " \n3) 8th Standard\n4) 9th Standard");
				n=sc.nextInt();
				switch(n)
				{
				case 1:
					n--;
					
					s.set9th();
					System.out.println("****************************************");
					System.out.println("             6 Th STANDARD              ");
					nth[n].check();
					
					break;
				case 2:
					n--;
					s.set9th();
					System.out.println("****************************************");
					System.out.println("             7 Th STANDARD              ");
					nth[n].check();
					break;
				case 3:
					n--;
					s.set9th();
					System.out.println("****************************************");
					System.out.println("             8 Th STANDARD              ");
					nth[n].check();
						break;
					case 4:
						n--;
						s.set9th();
						System.out.println("****************************************");
						System.out.println("             9 Th STANDARD              ");
						nth[n].check();
						
						break;
					
						default:
							System.out.println("Enter proper choice");
							break;
				
				}
					
				
				sc.nextLine();
				System.out.println("\n you want to continue then Enter yes");
				 c=sc.nextLine();
				}while(c.equals("yes")||c.equals("YES"));
				
				
				
				
				
				
				
				/****************************************************************************/
				break;
			case 3:
			
				s.set();
				System.out.println("****************************************");
				System.out.println("             10 th STANDARD              ");
				t.check();
				break;
			 default:
					System.out.println("Enter proper choice");
					break;
			
			}
				
			
			//sc.nextLine();
			System.out.println("ENTER  STUDENT Primary Secondary 10 th data then Enter yes");
			
			 c=sc.nextLine();
			}while(c.equals("yes")||c.equals("YES"));
			
			
			break;
			
		 default:
				System.out.println("Enter proper choice");
				break;
		
		}
			
		
		
		System.out.println("\n DO YOU WANT TO CONTINUE REPORT CARD GENERATE AND \n  ACCESS STUDENT THENE ENTER YES");
	
		 c=sc.nextLine();
		}while(c.equals("yes")||c.equals("YES"));
		
		System.out.println("\n  ***************END*********************          ");
	}

}
