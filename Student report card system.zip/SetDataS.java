package project;
import java.util.Scanner;
import java.util.Stack;
public class SetDataS {
	Stack<Integer> stack1=new Stack<Integer>();
	Stack<Integer> stack2=new Stack<Integer>();
	
	
	String studentMotherName[]=new String[30];
	int mathematics[]=new int[30];
	int English[]=new int[30];
	int Marathi[]=new int[30];
int Hindi[]=new int[30];
	int General_Scinece[]=new int[30];
	 int civics[]=new int[30];
	  int Geography[]=new int[30];
	double result[]=new double[30];
	double ResultMarks[]=new double[30];
	String[] Name;
	int RollNo[];
	String status[]=new String[30];
	 double[] percentage;
	 double[] newpercentage;
	 int rank[];
	 int j=0,k=0;
	 String c;
	 int[] temp=new int[5];
	 int num;
		int arr[];
		int newmarks;
		int count;
		int v=0;
		int m=0;
		
	 Scanner sc=new Scanner(System.in);
	
		public int set_Marks(int data)
		{

			try {
			if(data<0||data>100)
			{
				 ExceptionClass m=new  ExceptionClass();
				 throw m;
			}
			}
			catch(ExceptionClass e)
			{
				System.out.println("Marks Can Not be negative and greater than 100");
				System.out.println("Enter Again  mark");
				return newmarks=sc.nextInt();
			}
			
				return data;
		
		
		}

		
		public int RollNO_Validation(int data,int[] valid)
		{
			int	roll = 0;
		for(int i=0;i<valid.length;i++)
		{
			if(valid[i]==data||data>30)
			{
				try {
					 ExceptionClass m=new  ExceptionClass();
					 throw m;
				}
			catch(ExceptionClass e)
			{
				System.out.println("RollNo can not be duplicate and NOT greater than 30");
				System.out.println("Enter Again ");
			return roll=sc.nextInt();
			}
				
			}
		if(valid[i]==0)
		{
				valid[i]=data;
				break;
		}
			}
				return data;
		
		
		}

		
		
		
		
	void setData()
	{	System.out.println("Enter number of student data you want to Enter");
	num=sc.nextInt();
	percentage=new double[num];
	newpercentage=new double[num];
	Name=new String[num];
	RollNo=new int[num];
	arr=new int[num];
	rank=new int[num];
	int validRollno[]=new int[num];
	for(int k=0;k<num;k++)
	{
		
		sc.nextLine();
		System.out.println("***************************************");
	System.out.println("Enter Name marks");
	Name[k]=sc.nextLine();
	System.out.println("Enter RollNo ");
	
	RollNo[k]=RollNO_Validation(sc.nextInt(),validRollno);
	
	System.out.println("Enter Mathematics marks");
	mathematics[k]=set_Marks(sc.nextInt());
	System.out.println("Enter English marks");
	English[k]=set_Marks(sc.nextInt());	
	System.out.println("Enter Marathi marks");
	Marathi[k]=set_Marks(sc.nextInt());
	System.out.println("Enter Hindi marks");
	Hindi[k]=set_Marks(sc.nextInt());

	System.out.println("***************************************");
	}
		}
	
	
	void setData1()
	{	System.out.println("Enter number of student data you want to Enter");
	num=sc.nextInt();
	percentage=new double[num];
	newpercentage=new double[num];
	Name=new String[num];
	RollNo=new int[num];
	arr=new int[num];
	rank=new int[num];
	int validRollno[]=new int[num];
	for(int k=0;k<num;k++)
	{
		
		sc.nextLine();
		System.out.println("***************************************");
	System.out.println("Enter Name marks");
	Name[k]=sc.nextLine();
	System.out.println("Enter RollNo ");
	RollNo[k]=RollNO_Validation(sc.nextInt(),validRollno);
	System.out.println("Enter Mathematics marks");
	mathematics[k]=set_Marks(sc.nextInt());
	System.out.println("Enter English marks");
	English[k]=set_Marks(sc.nextInt());
	System.out.println("Enter Marathi marks");
	Marathi[k]=set_Marks(sc.nextInt());
	System.out.println("Enter Hindi marks");
	Hindi[k]=set_Marks(sc.nextInt());
	System.out.println("Enter General_Scinece marks");
	General_Scinece[k]=set_Marks(sc.nextInt());
	System.out.println("Enter civics marks");
	civics[k]=set_Marks(sc.nextInt());
	System.out.println("Enter Geography marks");
	Geography[k]=set_Marks(sc.nextInt());

	System.out.println("***************************************");
	}
		}

	void displayData(int k)
	{
		System.out.println("****************************************");
		System.out.println("     Name         ="+Name[k]);
		
		System.out.println("     RollNo       ="+RollNo[k]);
		System.out.println();
		System.out.println("           SUBJECT MARKS              ");
		System.out.println("     Mathematics  ="+mathematics[k]);
		
		System.out.println("     English      ="+English[k]);
		
		System.out.println("     Marathi      ="+Marathi[k]);

		System.out.println("     Hindi        ="+Hindi[k]);
		
		System.out.println("            PERCENTAGE "+percentage[k]);
		System.out.println("****************************************");
		
	}
	
	
	void displayData1(int k)
	{
		System.out.println("****************************************");
		System.out.println("     Name             ="+Name[k]);
		
		System.out.println("     RollNo           ="+RollNo[k]);
		System.out.println();
		System.out.println("            SUBJECT MARKS              ");
		System.out.println("     Mathematics      ="+mathematics[k]);
		
		System.out.println("     English          ="+English[k]);
		
		System.out.println("     Marathi          ="+Marathi[k]);

		System.out.println("     Hindi            ="+Hindi[k]);
		
        System.out.println("     General_Scinece  ="+General_Scinece[k]);
		
		System.out.println("     civics           ="+civics[k]);

		System.out.println("     Geography        ="+Geography[k]);
	//	for(int i=0;i<newpercentage.length;i++)
		//{
		//	if(newpercentage[i]==percentage[k])
		//	{
		//System.out.println("          PERCENTAGE  "+percentage[k]+"    RANK="+rank[i]);
		System.out.println("            PERCENTAGE  "+percentage[k]);
		System.out.println("                "+status[k]);
		System.out.println("****************************************");
			//}
		//}
	}
	void sort() {
		
		for(int i=0;i<newpercentage.length;i++)
		{
			newpercentage[i]=percentage[i];
			
		}
		
	       for (int i = 1; i < num; i++) { 
	    	  
	           double key = newpercentage[i]; 
	           int j = i - 1; 
	           while (j >= 0 && newpercentage[j] > key) { 
	           //	 count[m]=i;
	        	   newpercentage[j + 1] = newpercentage[j]; 
	               j = j - 1; 
	              
	           } 
	           newpercentage[j + 1] = key; 
	       } 
			
	
		
		for(int i=0;i<newpercentage.length;i++)
		{
			count=-1;
			for(int j=0;j<percentage.length;j++)
			{
				if(newpercentage[i]==percentage[j])
				{
				count++;
				break;
				}
				else {
					count++;
				}
			}
			arr[i]=count;
		}
		
	
		int l=rank.length-1;
		System.out.println("\n RANK ");
		for(int i=0;i<newpercentage.length;i++)
		{
			System.out.print(newpercentage[i]+" ");
			k=arr[i];
			int m=l;
			rank[i]=m+1;
		System.out.println(Name[k]+" rank="+rank[i]);
			l--;
		}
		
	
		//for(int i=0;i<arr.length;i++)
		//{
			
		//	j=arr[i];
			
	//	}
		
		
	}
	
}
