package project;

public class Tenth extends SetDataS {
static	String studentName;
static	int studentRollno1;
	int marks[]=new int[7];
	int ResultMark;
	String FP="PASS";
	int temp[]=new int[5];
	
	int[] sortMarks(int[] marks) {
	       for (int i = 1; i <marks.length; ++i) { 
	    	  
	           int key = marks[i]; 
	           int j = i - 1; 
	           while (j >= 0 && marks[j] > key) { 
	        	   marks[j + 1] = marks[j]; 
	               j = j - 1; 
	           } 
	           marks[j + 1] = key; 
	       } 		

		
		
		
		for(int i=marks.length-1,j=0;i>1;i--)
		{
			temp[j]=marks[i];
		
			j++;
		}
		return temp;
		
		
	}

	void display(){

		for(int j=0;j<num;j++)
		{
			marks[0]=mathematics[j];
			marks[1]=English[j];
			marks[2]=Marathi[j];
			marks[3]=Hindi[j];
			marks[4]=General_Scinece[j];
			marks[5]=civics[j];
			marks[6]=Geography[j];
			for(int i=0;i<marks.length;i++)
			{
				if(marks[i]<35)
				{
					FP="FAIL";
					break;
					
				}
				else {
					FP="PASS";
					
				}
			}
			
		temp=sortMarks(marks);
	for(int i=0;i<temp.length;i++)
	{
		ResultMark=ResultMark+temp[i];
		
	}
	
	ResultMarks[j]=ResultMark;
	percentage[j]=(ResultMarks[j]/500)*100;
     status[j]=FP;
System.out.println(Name[j]+"  "+status[j]);
	ResultMark=0;
			
		}
		
	}


	public void SetStudent(String name,int RollNo) {
		studentName=name;
		studentRollno1=RollNo;	}


	void check()
	{
		
		for(int i=0;i<num;i++)
		{
			
			if(Name[i].equals(studentName)&&RollNo[i]==studentRollno1)
				{
				displayData1(i);
				}
		}
	}
	
	
	
	
	
	
	
	int countp=0;
	int counts=0;
	void pushstatus()
	{
		
		for(int i=0;i<status.length;i++)
		{
			if(status[i]=="PASS")
			{
				stack1.push(i);
				countp++;
			}
			else if(status[i]=="FAIL"){
				stack2.push(i);
				counts++;
			}
		}

	}
	
	
	void popstatus()
	{
		System.out.println("  NUMBER OFF PASS STUDENT  :-"+countp);
		System.out.println();
		for(int i=0;i<countp;i++)
		{
			
			
				displayData1(stack1.peek());
				stack1.pop();
				
			}
		System.out.println("\n");
		System.out.println("  NUMBER OFF FAIL STUDENT  :-"+counts);
		System.out.println();
		
		for(int i=0;i<counts;i++)
		{
			displayData1(stack2.peek());
			stack2.pop();
			}

	}
		
	
}
