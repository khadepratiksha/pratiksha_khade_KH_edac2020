package project;

class  ExceptionClass extends Exception
{
	String excpMsg;

	ExceptionClass()
	{
	}
	ExceptionClass(String excpMsg)
	{
		super(excpMsg);
		this.excpMsg = excpMsg;
	}

/*	public String getMessage()
	{
		
		return "MyException: "+excpMsg;
	}
	public String toString()
	{
		return excpMsg;
	}
*/
	
}
