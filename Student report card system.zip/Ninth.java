package project;

public class Ninth extends SetDataS {
	static String studentName;
	 static int studentRollno3;
	int marks[]=new int[7];
	int ResultMark;
	String FP="PASS";
	int temp[]=new int[5];
	
	void display(){

		for(int j=0;j<num;j++)
		{
			marks[0]=mathematics[j];
			marks[1]=English[j];
			marks[2]=Marathi[j];
			marks[3]=Hindi[j];
			marks[4]=General_Scinece[j];
			marks[5]=civics[j];
			marks[6]=Geography[j];
			
			for(int i=0;i<marks.length;i++)
			{

				ResultMark=ResultMark+marks[k];
			}
			for(int i=0;i<marks.length;i++)
			{
				if(marks[i]<35)
				{
					FP="FAIL";
					break;	
				}
				else {
					FP="PASS";
				}
				
			}
	ResultMarks[j]=ResultMark;
	percentage[j]=(ResultMarks[j]/700)*100;
     status[j]=FP;
	//System.out.println(percentage[j]+"  "+Name[j]);
	ResultMark=0;
			
		}
		
	}



	public void SetStudent(String name,int RollNo) {
		studentName=name;
		studentRollno3=RollNo;
	}


	void check()
	{
		
		for(int i=0;i<num;i++)
		{
			
			if(Name[i].equals(studentName)&&RollNo[i]==studentRollno3)
				{
				displayData1(i);
				}
		}
	}
	
	
	
	
	
	
	int countp=0;
	int counts=0;
	void pushstatus()
	{
		
		for(int i=0;i<status.length;i++)
		{
			if(status[i]=="PASS")
			{
				stack1.push(i);
				countp++;
			}
			else if(status[i]=="FAIL"){
				stack2.push(i);
				counts++;
			}
		}

	}
	
	
	void popstatus()
	{
		System.out.println("  NUMBER OFF PASS STUDENT  :-"+countp);
		for(int i=0;i<countp;i++)
		{
			
			//System.out.println(stack1.peek()+" pop "+stack1.pop());
				displayData1(stack1.peek());
				//System.out.println("second"+stack1.peek()+" pop "+stack1.pop());
				//stack1.pop();
				stack1.pop();
				
			}

		
		System.out.println("  NUMBER OFF FAIL STUDENT  :-"+counts);
		System.out.println();
		
		for(int i=0;i<counts;i++)
		{
			displayData1(stack2.peek());
			stack2.pop();
			}

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
