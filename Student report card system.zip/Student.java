package project;

import java.util.Scanner;

public  class Student extends SetDataS{
	Scanner sc=new Scanner(System.in);
	FirstStandard f=new FirstStandard();
	Ninth nth=new Ninth();
	Tenth tt=new Tenth();
	static int m=0,n=0;;
	String Name;
	int RollNo;
Student()
{	
	RollNo=0;
	Name=null;
	
}
void setData()
{

	System.out.println("Enter Name ");
	Name=sc.nextLine();
	System.out.println("Enter RollNo");
	RollNo=sc.nextInt();
	f.SetStudent(Name,RollNo);
	sc.nextLine();
	
}
void set()
{
	
	
	System.out.println("Enter Name");
	Name=sc.nextLine();
	System.out.println("Enter RollNo");
	RollNo=sc.nextInt();
	tt.SetStudent(Name,RollNo);
	sc.nextLine();
	
}

void set9th()
{
	
	
	System.out.println("Enter Name");
	Name=sc.nextLine();
	System.out.println("Enter RollNo");
	RollNo=sc.nextInt();
	nth.SetStudent(Name,RollNo);
	sc.nextLine();
	
}
}

