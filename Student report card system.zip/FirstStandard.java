package project;

import java.util.Scanner;

public class FirstStandard extends SetDataS {
	static String studentNamen;
	static int studentRollno;
void display(){
	for(int j=0;j<num;j++)
	{
		
result[j]=mathematics[j]+English[j]+Marathi[j]+Hindi[j];
		
		percentage[j]=(result[j]/400)*100;
		
	System.out.println(percentage[j]+"  "+Name[j]);
	
	}
	

}


public void SetStudent(String name,int Rollno) {
	
	studentNamen=name;
	studentRollno=Rollno;
	
}


void check()
{
	
	for(int i=0;i<num;i++)
	{
		
		if(Name[i].equals(studentNamen)&&RollNo[i]==studentRollno)
			{
			displayData(i);
			}
		
	}
}
}
